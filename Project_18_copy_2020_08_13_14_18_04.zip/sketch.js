var  bananaImage ,obstacleImage ,obstacleGroup , foodGroup;
var backGround , backImage ,  score ,  player_running , player ; 

function preload() {
  
  backImage = loadImage("jungle.png");
  bananaImage = loadImage("Banana.png");
  obstacleImage = loadImage("stone.png");
  player_running = loadAnimation("Monkey_01.png" , "Monkey_02.png", "     Monkey_03.png" , "Monkey_04.png", "Monkey_05.png"  , "Monkey_06.png" , "Monkey_07.png","Monkey_08.png", "Monkey_09.png" , "Monkey_10.png");

}

function setup() {
  createCanvas(400, 400);
  

 backGround = createSprite(200 , 200 , 400 , 400 );
  backGround.addImage("bi", backImage);
  
  player.addAnimation("Pa" , player_running );
}

function draw() {
  background(220);
  score = 0 ;
  stoke("white");
  textSize(20);
  fill("white");
  text("Score : " + score , 500 ,50);
  
  backGround.velocityX = -5 ;
  backGround.visible = false;
  
  if (foodGroup.isTouching( player) ) {
    score = score+2;
  }
  
  if (obstaclesGroup.isTouching( player )) {
    player.scale = 0.2 ;
  }
  
  switch ( score ) {
      case 1:
      player.scale = 0.12 ; 
      break;
      case 2:
      player.scale = 0.14 ; 
      break;
      case 3 :
      player.scale = 0.16 ; 
      break;
      case 4 :
      player.scale = 0.18 ; 
      break;
      default:
      break;

  
  
}
}

